﻿namespace ItroublveTSC
{
    partial class Advanced
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Advanced));
            this.HeadLinePnlInf = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.pnlRainbowTop = new System.Windows.Forms.Panel();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.HeadServerLbl = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.RainbowTimer = new System.Windows.Forms.Timer(this.components);
            this.PnlRainbowDown = new System.Windows.Forms.Panel();
            this.Path2Ico = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.HomeBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.AssemblyFileVTxt = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.AssemblyCopyrTxt = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.AssemblyProdTxt = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.AssemblyDescTxt = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.AssemblyTitleTxt = new System.Windows.Forms.TextBox();
            this.IconPrePic = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ExeCopy_assembly = new RoundBtn();
            this.MsgBoxBtn = new RoundBtn();
            this.CstmIcon = new RoundBtn();
            this.HeadLinePnlInf.SuspendLayout();
            this.PnlRainbowDown.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.IconPrePic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // HeadLinePnlInf
            // 
            this.HeadLinePnlInf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.HeadLinePnlInf.Controls.Add(this.button5);
            this.HeadLinePnlInf.Controls.Add(this.pnlRainbowTop);
            this.HeadLinePnlInf.Controls.Add(this.CloseBtn);
            this.HeadLinePnlInf.Controls.Add(this.HeadServerLbl);
            this.HeadLinePnlInf.Controls.Add(this.panel25);
            this.HeadLinePnlInf.Controls.Add(this.comboBox3);
            this.HeadLinePnlInf.Controls.Add(this.textBox3);
            this.HeadLinePnlInf.Controls.Add(this.button4);
            this.HeadLinePnlInf.Controls.Add(this.panel26);
            this.HeadLinePnlInf.Controls.Add(this.panel27);
            this.HeadLinePnlInf.Controls.Add(this.panel36);
            this.HeadLinePnlInf.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeadLinePnlInf.Location = new System.Drawing.Point(0, 0);
            this.HeadLinePnlInf.Name = "HeadLinePnlInf";
            this.HeadLinePnlInf.Size = new System.Drawing.Size(537, 27);
            this.HeadLinePnlInf.TabIndex = 6307;
            this.HeadLinePnlInf.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeadLinePnlInf_MouseDown);
            this.HeadLinePnlInf.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeadLinePnlInf_MouseMove);
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(110)))), ((int)(((byte)(123)))));
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Impact", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(480, 0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(26, 25);
            this.button5.TabIndex = 6223;
            this.button5.Text = "-";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // pnlRainbowTop
            // 
            this.pnlRainbowTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.pnlRainbowTop.Location = new System.Drawing.Point(0, 25);
            this.pnlRainbowTop.Name = "pnlRainbowTop";
            this.pnlRainbowTop.Size = new System.Drawing.Size(3814, 2);
            this.pnlRainbowTop.TabIndex = 6222;
            // 
            // CloseBtn
            // 
            this.CloseBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.CloseBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(110)))), ((int)(((byte)(123)))));
            this.CloseBtn.FlatAppearance.BorderSize = 0;
            this.CloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseBtn.Font = new System.Drawing.Font("Webdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.CloseBtn.ForeColor = System.Drawing.Color.White;
            this.CloseBtn.Location = new System.Drawing.Point(508, -1);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(26, 25);
            this.CloseBtn.TabIndex = 6167;
            this.CloseBtn.Text = "r";
            this.CloseBtn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.CloseBtn.UseVisualStyleBackColor = false;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // HeadServerLbl
            // 
            this.HeadServerLbl.AutoSize = true;
            this.HeadServerLbl.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HeadServerLbl.ForeColor = System.Drawing.Color.White;
            this.HeadServerLbl.Location = new System.Drawing.Point(175, 3);
            this.HeadServerLbl.Name = "HeadServerLbl";
            this.HeadServerLbl.Size = new System.Drawing.Size(197, 21);
            this.HeadServerLbl.TabIndex = 6166;
            this.HeadServerLbl.Text = "ItroublveTSC | Advanced";
            this.HeadServerLbl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeadServerLbl_MouseDown);
            this.HeadServerLbl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeadServerLbl_MouseMove);
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.panel25.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.panel25.Location = new System.Drawing.Point(362, -44);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(2, 25);
            this.panel25.TabIndex = 6160;
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.comboBox3.ForeColor = System.Drawing.Color.Silver;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(364, -44);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(254, 25);
            this.comboBox3.TabIndex = 6154;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Location = new System.Drawing.Point(364, -42);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(231, 21);
            this.textBox3.TabIndex = 6156;
            this.textBox3.Text = " Voice Channel";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(68)))), ((int)(((byte)(173)))));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Webdings", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button4.ForeColor = System.Drawing.Color.Silver;
            this.button4.Location = new System.Drawing.Point(594, -43);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(25, 22);
            this.button4.TabIndex = 6155;
            this.button4.Text = "6";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.panel26.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.panel26.Location = new System.Drawing.Point(364, -21);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(254, 2);
            this.panel26.TabIndex = 6157;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.panel27.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.panel27.Location = new System.Drawing.Point(364, -44);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(254, 2);
            this.panel27.TabIndex = 6158;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.panel36.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.panel36.Location = new System.Drawing.Point(617, -44);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(2, 25);
            this.panel36.TabIndex = 6159;
            // 
            // RainbowTimer
            // 
            this.RainbowTimer.Tick += new System.EventHandler(this.RainbowTimer_Tick);
            // 
            // PnlRainbowDown
            // 
            this.PnlRainbowDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.PnlRainbowDown.Controls.Add(this.Path2Ico);
            this.PnlRainbowDown.Location = new System.Drawing.Point(-1631, 480);
            this.PnlRainbowDown.Name = "PnlRainbowDown";
            this.PnlRainbowDown.Size = new System.Drawing.Size(3814, 2);
            this.PnlRainbowDown.TabIndex = 6308;
            // 
            // Path2Ico
            // 
            this.Path2Ico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.Path2Ico.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Path2Ico.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Path2Ico.ForeColor = System.Drawing.Color.DarkGray;
            this.Path2Ico.Location = new System.Drawing.Point(1764, -12);
            this.Path2Ico.Name = "Path2Ico";
            this.Path2Ico.ReadOnly = true;
            this.Path2Ico.Size = new System.Drawing.Size(342, 18);
            this.Path2Ico.TabIndex = 6354;
            this.Path2Ico.Visible = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button6);
            this.panel7.Controls.Add(this.button3);
            this.panel7.Controls.Add(this.button2);
            this.panel7.Controls.Add(this.HomeBtn);
            this.panel7.Controls.Add(this.button1);
            this.panel7.Location = new System.Drawing.Point(0, 28);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(95, 451);
            this.panel7.TabIndex = 6343;
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(0, 393);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(95, 58);
            this.button6.TabIndex = 6355;
            this.button6.Text = "Credits";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(0, 197);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(95, 93);
            this.button3.TabIndex = 6345;
            this.button3.Text = "File  Stealer";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(0, 90);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 101);
            this.button2.TabIndex = 6344;
            this.button2.Text = "Advanced Options";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // HomeBtn
            // 
            this.HomeBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.HomeBtn.FlatAppearance.BorderSize = 0;
            this.HomeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HomeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeBtn.ForeColor = System.Drawing.Color.White;
            this.HomeBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.HomeBtn.Location = new System.Drawing.Point(0, 0);
            this.HomeBtn.Name = "HomeBtn";
            this.HomeBtn.Size = new System.Drawing.Size(95, 87);
            this.HomeBtn.TabIndex = 6341;
            this.HomeBtn.Text = "Stealer";
            this.HomeBtn.UseVisualStyleBackColor = true;
            this.HomeBtn.Click += new System.EventHandler(this.HomeBtn_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(0, 296);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 91);
            this.button1.TabIndex = 6343;
            this.button1.Text = "File Pumper";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.panel6.Controls.Add(this.AssemblyFileVTxt);
            this.panel6.Location = new System.Drawing.Point(111, 227);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(197, 32);
            this.panel6.TabIndex = 6349;
            // 
            // AssemblyFileVTxt
            // 
            this.AssemblyFileVTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.AssemblyFileVTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AssemblyFileVTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssemblyFileVTxt.ForeColor = System.Drawing.Color.DarkGray;
            this.AssemblyFileVTxt.Location = new System.Drawing.Point(7, 7);
            this.AssemblyFileVTxt.Name = "AssemblyFileVTxt";
            this.AssemblyFileVTxt.Size = new System.Drawing.Size(185, 18);
            this.AssemblyFileVTxt.TabIndex = 6153;
            this.AssemblyFileVTxt.Text = "File Version";
            this.AssemblyFileVTxt.Enter += new System.EventHandler(this.AssemblyFileVTxt_Enter);
            this.AssemblyFileVTxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AssemblyFileVTxt_KeyDown);
            this.AssemblyFileVTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AssemblyFileVTxt_KeyPress);
            this.AssemblyFileVTxt.Leave += new System.EventHandler(this.AssemblyFileVTxt_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.panel2.Controls.Add(this.AssemblyCopyrTxt);
            this.panel2.Location = new System.Drawing.Point(110, 180);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(395, 32);
            this.panel2.TabIndex = 6347;
            // 
            // AssemblyCopyrTxt
            // 
            this.AssemblyCopyrTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.AssemblyCopyrTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AssemblyCopyrTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssemblyCopyrTxt.ForeColor = System.Drawing.Color.DarkGray;
            this.AssemblyCopyrTxt.Location = new System.Drawing.Point(7, 7);
            this.AssemblyCopyrTxt.Name = "AssemblyCopyrTxt";
            this.AssemblyCopyrTxt.Size = new System.Drawing.Size(379, 18);
            this.AssemblyCopyrTxt.TabIndex = 6153;
            this.AssemblyCopyrTxt.Text = "Assembly © Copyright";
            this.AssemblyCopyrTxt.Enter += new System.EventHandler(this.AssemblyCopyrTxt_Enter);
            this.AssemblyCopyrTxt.Leave += new System.EventHandler(this.AssemblyCopyrTxt_Leave);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.panel3.Controls.Add(this.AssemblyProdTxt);
            this.panel3.Location = new System.Drawing.Point(110, 134);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(395, 32);
            this.panel3.TabIndex = 6346;
            // 
            // AssemblyProdTxt
            // 
            this.AssemblyProdTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.AssemblyProdTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AssemblyProdTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssemblyProdTxt.ForeColor = System.Drawing.Color.DarkGray;
            this.AssemblyProdTxt.Location = new System.Drawing.Point(7, 7);
            this.AssemblyProdTxt.Name = "AssemblyProdTxt";
            this.AssemblyProdTxt.Size = new System.Drawing.Size(379, 18);
            this.AssemblyProdTxt.TabIndex = 6153;
            this.AssemblyProdTxt.Text = "Assembly Product Here";
            this.AssemblyProdTxt.Enter += new System.EventHandler(this.AssemblyProdTxt_Enter);
            this.AssemblyProdTxt.Leave += new System.EventHandler(this.AssemblyProdTxt_Leave);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.panel4.Controls.Add(this.AssemblyDescTxt);
            this.panel4.Location = new System.Drawing.Point(110, 87);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(395, 33);
            this.panel4.TabIndex = 6345;
            // 
            // AssemblyDescTxt
            // 
            this.AssemblyDescTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.AssemblyDescTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AssemblyDescTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssemblyDescTxt.ForeColor = System.Drawing.Color.DarkGray;
            this.AssemblyDescTxt.Location = new System.Drawing.Point(7, 7);
            this.AssemblyDescTxt.Name = "AssemblyDescTxt";
            this.AssemblyDescTxt.Size = new System.Drawing.Size(379, 18);
            this.AssemblyDescTxt.TabIndex = 6153;
            this.AssemblyDescTxt.Text = "Assembly Description Here";
            this.AssemblyDescTxt.Enter += new System.EventHandler(this.AssemblyDescTxt_Enter);
            this.AssemblyDescTxt.Leave += new System.EventHandler(this.AssemblyDescTxt_Leave);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.panel5.Controls.Add(this.AssemblyTitleTxt);
            this.panel5.Location = new System.Drawing.Point(111, 42);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(395, 33);
            this.panel5.TabIndex = 6344;
            // 
            // AssemblyTitleTxt
            // 
            this.AssemblyTitleTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(50)))), ((int)(((byte)(55)))));
            this.AssemblyTitleTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AssemblyTitleTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssemblyTitleTxt.ForeColor = System.Drawing.Color.DarkGray;
            this.AssemblyTitleTxt.Location = new System.Drawing.Point(7, 7);
            this.AssemblyTitleTxt.Name = "AssemblyTitleTxt";
            this.AssemblyTitleTxt.Size = new System.Drawing.Size(379, 18);
            this.AssemblyTitleTxt.TabIndex = 6153;
            this.AssemblyTitleTxt.Text = "Assembly Title Here";
            this.AssemblyTitleTxt.TextChanged += new System.EventHandler(this.AssemblyTitleTxt_TextChanged);
            this.AssemblyTitleTxt.Enter += new System.EventHandler(this.AssemblyTitleTxt_Enter);
            this.AssemblyTitleTxt.Leave += new System.EventHandler(this.AssemblyTitleTxt_Leave);
            // 
            // IconPrePic
            // 
            this.IconPrePic.BackColor = System.Drawing.Color.Transparent;
            this.IconPrePic.Location = new System.Drawing.Point(351, 285);
            this.IconPrePic.MinimumSize = new System.Drawing.Size(155, 116);
            this.IconPrePic.Name = "IconPrePic";
            this.IconPrePic.Size = new System.Drawing.Size(155, 123);
            this.IconPrePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.IconPrePic.TabIndex = 6350;
            this.IconPrePic.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.GrayText;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.No;
            this.pictureBox1.Location = new System.Drawing.Point(345, 277);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 138);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6351;
            this.pictureBox1.TabStop = false;
            // 
            // ExeCopy_assembly
            // 
            this.ExeCopy_assembly.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(205)))));
            this.ExeCopy_assembly.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(205)))));
            this.ExeCopy_assembly.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.ExeCopy_assembly.FlatAppearance.BorderSize = 0;
            this.ExeCopy_assembly.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.ExeCopy_assembly.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.ExeCopy_assembly.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExeCopy_assembly.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.ExeCopy_assembly.Location = new System.Drawing.Point(345, 234);
            this.ExeCopy_assembly.Name = "ExeCopy_assembly";
            this.ExeCopy_assembly.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(99)))), ((int)(((byte)(180)))));
            this.ExeCopy_assembly.OnHoverButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(99)))), ((int)(((byte)(180)))));
            this.ExeCopy_assembly.OnHoverTextColor = System.Drawing.Color.White;
            this.ExeCopy_assembly.Size = new System.Drawing.Size(167, 27);
            this.ExeCopy_assembly.TabIndex = 6353;
            this.ExeCopy_assembly.Text = "COPY EXE INFO";
            this.ExeCopy_assembly.TextColor = System.Drawing.Color.White;
            this.ExeCopy_assembly.UseVisualStyleBackColor = true;
            this.ExeCopy_assembly.Click += new System.EventHandler(this.ExeCopy_assembly_Click);
            // 
            // MsgBoxBtn
            // 
            this.MsgBoxBtn.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(205)))));
            this.MsgBoxBtn.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(205)))));
            this.MsgBoxBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.MsgBoxBtn.FlatAppearance.BorderSize = 0;
            this.MsgBoxBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.MsgBoxBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.MsgBoxBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MsgBoxBtn.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.MsgBoxBtn.Location = new System.Drawing.Point(111, 435);
            this.MsgBoxBtn.Name = "MsgBoxBtn";
            this.MsgBoxBtn.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(99)))), ((int)(((byte)(180)))));
            this.MsgBoxBtn.OnHoverButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(99)))), ((int)(((byte)(180)))));
            this.MsgBoxBtn.OnHoverTextColor = System.Drawing.Color.White;
            this.MsgBoxBtn.Size = new System.Drawing.Size(158, 27);
            this.MsgBoxBtn.TabIndex = 6352;
            this.MsgBoxBtn.Text = "MESSAGEBOX";
            this.MsgBoxBtn.TextColor = System.Drawing.Color.White;
            this.MsgBoxBtn.UseVisualStyleBackColor = true;
            this.MsgBoxBtn.Click += new System.EventHandler(this.MsgBoxBtn_Click);
            // 
            // CstmIcon
            // 
            this.CstmIcon.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(205)))));
            this.CstmIcon.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(205)))));
            this.CstmIcon.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.CstmIcon.FlatAppearance.BorderSize = 0;
            this.CstmIcon.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.CstmIcon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.CstmIcon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CstmIcon.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.CstmIcon.Location = new System.Drawing.Point(357, 435);
            this.CstmIcon.Name = "CstmIcon";
            this.CstmIcon.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(99)))), ((int)(((byte)(180)))));
            this.CstmIcon.OnHoverButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(99)))), ((int)(((byte)(180)))));
            this.CstmIcon.OnHoverTextColor = System.Drawing.Color.White;
            this.CstmIcon.Size = new System.Drawing.Size(155, 27);
            this.CstmIcon.TabIndex = 6348;
            this.CstmIcon.Text = "ADD CUSTOM ICON";
            this.CstmIcon.TextColor = System.Drawing.Color.White;
            this.CstmIcon.UseVisualStyleBackColor = true;
            this.CstmIcon.Click += new System.EventHandler(this.CstmIcon_Click);
            // 
            // Advanced
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.ClientSize = new System.Drawing.Size(537, 494);
            this.Controls.Add(this.ExeCopy_assembly);
            this.Controls.Add(this.MsgBoxBtn);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.CstmIcon);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.IconPrePic);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.PnlRainbowDown);
            this.Controls.Add(this.HeadLinePnlInf);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Advanced";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ItroublveTSC";
            this.Load += new System.EventHandler(this.Advanced_Load);
            this.HeadLinePnlInf.ResumeLayout(false);
            this.HeadLinePnlInf.PerformLayout();
            this.PnlRainbowDown.ResumeLayout(false);
            this.PnlRainbowDown.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.IconPrePic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel HeadLinePnlInf;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel pnlRainbowTop;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Label HeadServerLbl;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Timer RainbowTimer;
        private System.Windows.Forms.Panel PnlRainbowDown;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button HomeBtn;
        private System.Windows.Forms.Button button1;
        private RoundBtn MsgBoxBtn;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox AssemblyFileVTxt;
        private RoundBtn CstmIcon;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox AssemblyCopyrTxt;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox AssemblyProdTxt;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox AssemblyDescTxt;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox IconPrePic;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox Path2Ico;
        public System.Windows.Forms.TextBox AssemblyTitleTxt;
        private System.Windows.Forms.Button button6;
        private RoundBtn ExeCopy_assembly;
    }
}